# Experiment Readout Copilot

Raw A/B test results in → a statistically rigorous ship/no-ship decision and an
executive-ready memo out — grounded in prior-experiment memory, with a published
evaluation suite.

**Live demo:** _[your Streamlit URL]_ · **Demo video:** _[Loom link]_

---

## The problem

Product teams don't suffer from slow readout writing — they suffer from **bad calls
dressed as readouts**: tests declared winners while underpowered, sample-ratio
mismatches celebrated as lifts, "significant" effects too small to matter, and lately,
AI summaries that quietly miscompute the statistics they narrate. The job to be done is
a readout where the math is trustworthy by construction and the writing takes seconds.

**Target user:** PMs and analysts running conversion experiments without a dedicated
experimentation platform team.

## The one rule

> **Code calculates. AI narrates.**

The statistics engine (`stats.py`) computes every number: two-proportion z-test,
95% confidence interval, sample-ratio-mismatch check, and power analysis. The language
model receives those numbers verbatim and is contractually forbidden (system prompt)
from deriving, recomputing, or inventing any figure — and is **judged on exactly that**
by the eval suite's faithfulness layer. In a decision-support tool, LLM arithmetic is a
hallucination surface; this design removes it.

## What it does

```
results (4 numbers or CSV)
   └─► stats engine: z-test · CI · SRM check · power check ──► DECISION + rationale
            └─► BM25 retrieval over 40 prior-experiment readouts ──► similar tests & learnings
                     └─► Claude (narrate-only) ──► executive memo

"Have we ever tested X?"
   └─► BM25 retrieval (top-4 readouts) ──► Claude (grounded, cites [EXP-IDs], refuses
                                            when the history doesn't cover it)
```

Two RAG surfaces: the memo is *augmented* by retrieved priors; **Ask Your History** is
the full retrieve→ground→generate→refuse loop over institutional experiment memory.

**Decision policy** (deterministic, documented, regression-tested):

| Condition | Call |
|---|---|
| Sample-ratio mismatch (p < 0.001) | **INVESTIGATE** — the read is invalid until assignment is diagnosed |
| Zero conversions in both arms | **INVESTIGATE** — tracking problem until proven otherwise |
| p < 0.05, positive lift | **SHIP** (with guardrail note) |
| p < 0.05, negative lift | **DO NOT SHIP** |
| p ≥ 0.3 and \|lift\| < 2% | **DO NOT SHIP** — practical equivalence; more data won't change the product call |
| Not significant, underpowered | **KEEP RUNNING** — reports the N/arm actually required |
| Not significant, adequately powered | **DO NOT SHIP** — no detectable effect |

**Prior-experiment memory:** 16 readouts (synthetic, modeled on real retail
experimentation patterns) indexed with BM25; the memo can cite a similar past test —
"a comparable urgency-badge win decayed by week 4 (EXP-022); recommend a holdback."

## Evaluation

| Layer | What it measures | Result |
|---|---|---|
| Decision regression suite — 20 locked scenarios | Stats-engine correctness; calls can't silently change | **20/20 pass** |
| History retrieval — 10 questions over 40 readouts | RAG layer: expected readout in top-4 | **9/10 (90%)** |
| Memo faithfulness — LLM-judged on 5 scenarios | AI layer: numbers verbatim, decision respected, no invented priors | _run in app → Evals tab_ |

The 20 scenarios include the canonical winner, a significant loser, underpowered reads,
two SRM traps, a borderline pair straddling p = 0.05, zero-conversion tracking failure,
and an exact null at scale.

**The eval suite earned its keep before launch:** the original policy told the
exact-null-at-scale case (G06) to *keep running* — toward a computed requirement of
**2.2 billion users per arm**. That finding produced the practical-equivalence guard.
Same story for zero-conversion arms (G18), now correctly flagged as a tracking
investigation. Evals aren't decoration; they changed the product.

## Known limitations (v1, stated honestly)

- Single primary metric; no guardrail-metric math yet (the memo flags guardrails
  qualitatively via retrieved priors).
- Frequentist only; no sequential-testing correction, so peek-early-peek-often
  workflows can still inflate false positives.
- The prior-experiment library is synthetic — retrieval quality is real, institutional
  memory is illustrative.
- BM25 memory misses synonyms — the eval suite's one retrieval miss is exactly this:
  the query says "sample ratio mismatch," the readout says "SRM." Kept as a published
  miss rather than patched, because it's the measured case for embeddings in v2.

## V2

Guardrail metrics with non-inferiority bounds · sequential testing (mSPRT) ·
Bayesian readout alongside frequentist · CSV import from Amplitude/Mixpanel exports ·
embedding + rerank memory measured against this same gold set · feedback loop where
shipped readouts become new memory entries.

## Build notes

Built by **Christian Burnham** — problem selection, the code-calculates/AI-narrates
rule, the decision policy and its guards, gold-set design, and the tradeoffs above are
mine. Much of the implementation was generated under my direction with Claude
(Anthropic): PM-led, AI-accelerated, eval-verified. That working style is the point.

*Educational prototype, not a substitute for your experimentation platform's stats.*
