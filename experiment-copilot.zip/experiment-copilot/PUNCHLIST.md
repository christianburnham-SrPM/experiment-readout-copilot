# Your Remaining 20% (browser only — see DEPLOY_GUIDE.md for buttons)

1. Read README.md and INTERVIEW_QUESTIONS.md once, slowly (1 hr). Edit anything
   that isn't your voice — especially the gold-set scenario names if you want them
   closer to tests you actually ran.
2. Follow DEPLOY_GUIDE.md Steps 0–3 (accounts → upload → deploy → key). ~35 min.
3. In the live app: Evals tab → run both layers → put the numbers in the README
   (Guide Step 4). ~10 min.
4. Loom, 60–90 seconds, screen-recording the app:
   - "PMs don't suffer from slow readouts — they suffer from bad calls."
   - Enter the canonical 3.2→3.8 test → SHIP card → "every number here is computed
     in code; the AI is only allowed to narrate."
   - Show a similar prior experiment retrieved → click memo.
   - Open Evals → 20/20 → "the suite caught my own policy twice before launch."
5. LinkedIn: Featured links (app + repo), then post — post_draft.md, edited to you.
6. Send Claude the live URL → sabbatical line updated same day.
