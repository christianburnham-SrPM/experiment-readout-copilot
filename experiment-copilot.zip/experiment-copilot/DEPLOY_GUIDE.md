# Deploy Guide — Browser Only, No Terminal, ~45 Minutes

Every step below happens in a web browser. There are no commands to type anywhere.
You'll create two free accounts, drag files into a page, paste one key into a form,
and click Deploy.

---

## Step 0 — Two free accounts (10 min)

1. **GitHub** (where the code lives, publicly): go to **github.com → Sign up**.
   Pick a professional username — it appears in your project URL
   (e.g., `github.com/christianburnham`).
2. **Anthropic API key** (powers the memo writer, ~$5 covers everything): go to
   **console.anthropic.com → sign up → API Keys → Create Key**. Copy it somewhere
   safe — you'll paste it once in Step 3. Add $5 of credit under Billing.

## Step 1 — Put the project on GitHub (10 min)

1. On github.com, click the **+** (top right) → **New repository**.
2. Name: `experiment-readout-copilot` · set **Public** · check **"Add a README"** → **Create repository**.
3. On your new repo page: **Add file → Upload files**.
4. Drag **all the files from this folder** (everything in the zip, except this guide
   and PUNCHLIST if you prefer) into the upload box. The folder is deliberately flat —
   no subfolders — so drag-and-drop just works.
5. Important: GitHub created a placeholder README in step 2; your upload includes the
   real `README.md` and will replace it. Confirm the green **Commit changes** button.

That's it — your code is published.

## Step 2 — Deploy on Streamlit Community Cloud (10 min)

1. Go to **share.streamlit.io** → **Continue with GitHub** (it'll ask permission to
   see your repositories — allow it).
2. Click **Create app** (or "New app") → **Deploy a public app from GitHub**.
3. Repository: pick `experiment-readout-copilot` · Branch: `main` ·
   Main file path: `app.py` → **Deploy**.
4. It builds for 2–3 minutes. When it loads, the app works immediately —
   statistics and the eval suite need no key.

## Step 3 — Add your API key (5 min)

1. In Streamlit Cloud, open your app's menu (**⋮** bottom right of the app card, or
   **Settings** from the app page) → **Settings → Secrets**.
2. Paste exactly this (with your real key) into the box and **Save**:

   ```
   ANTHROPIC_API_KEY = "sk-ant-your-key-here"
   ```

3. The app restarts itself. The "Write executive memo" button and Evals Layer 2
   now work.

## Step 4 — Run your evals and put the numbers in the README (10 min)

1. In your live app, open the **Evals** tab.
2. Click **Run decision regression suite** → you should see **20/20 pass**.
3. Click **Run memo faithfulness** → note the result (expect 5/5 or 4/5; if a memo
   fails, read why in the expander — that's a finding, not a failure, and worth a
   sentence in the README).
4. Back on GitHub: open `README.md` → click the **pencil icon** (Edit) → replace the
   two `_run in app_` placeholders in the results table with your numbers, and paste
   your live app URL at the top → **Commit changes**.

## Step 5 — Publish (15 min)

1. **Loom** (free, loom.com): record 60–90 seconds — script in `PUNCHLIST.md`.
2. **LinkedIn**: Profile → **Add profile section → Featured → Add link** twice
   (live app + GitHub repo). Then post — draft in `post_draft.md`, edit to your voice.
3. Send Claude the live URL → the resume's sabbatical line gets updated the same day.

---

**If anything breaks:** the app page on Streamlit Cloud has a **Manage app → Logs**
button — copy the red error text and paste it to Claude. Ninety percent of first-deploy
issues are a typo in the Secrets box (the quotes matter).
